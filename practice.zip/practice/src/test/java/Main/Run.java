package Main;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import BaseClass.LibGlobal;
import Utils.Excel_Utils;



public class Run extends LibGlobal {
	int count = 0;
	static int respCode = 200;
	static HttpURLConnection huc = null;
	LibGlobal lb = new LibGlobal();

	@DataProvider
	public Iterator<Object[]> getTestData() {
		ArrayList<Object[]> testData = Excel_Utils.getDataFromexcel();
		return testData.iterator();
	}

	static ExtentTest test;
	static ExtentReports report;

	@Parameters("browser")
	   @BeforeTest
	   private void browserExe() {

		   launchBrowser("chrome");
		
	}

	@Test
	(dataProvider = "getTestData")
	public void PageURLverify(String INDEX, String PageURL, String Title, String Description, String keywords)
			throws Exception {
		


		 Thread.sleep(2000);
	
		//===================================
		long start = System.currentTimeMillis();
		loadUrl(PageURL);
		long ends = System.currentTimeMillis();
		long total = ends - start;
		long loadingtimeinsecond = total / 1000;

		String Seconds = String.valueOf(loadingtimeinsecond);
		String stotal = String.valueOf(total);
	    int   iBrokenImageCount = 0;
		
		huc = (HttpURLConnection) (new URL(PageURL).openConnection());

		huc.setRequestMethod("HEAD");

		huc.connect();

		respCode = huc.getResponseCode();

		if (respCode >= 400) {
			
			System.out.println(PageURL + " is a broken link" + " " + respCode);
			System.out.println("fail");
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel11(respCode, parseInt);

		} else {
			
			System.out.println(PageURL + " is a valid link" + " " + respCode);
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel11(respCode, parseInt);

			if (total <= 4000) {

				System.out.println("Page load Second");
				System.out.println("pass");
				System.out.println(Seconds);
				System.out.println(stotal);

			}

		
		}
	//broken Image 
	 

			
		//end broken Image 
		
		
		//========================================
		//canonical tag
		   try {
				driver.findElement(By.xpath("//link[@rel='canonical']"));
				int parseInt = Integer.parseInt(INDEX);
	  			Excel_Utils.writeinexcel10("PASS", parseInt);
				System.out.println("canonical is pass");
			} catch (Exception e1) {
				int parseInt = Integer.parseInt(INDEX);
	  			Excel_Utils.writeinexcel10("FAIL", parseInt);
				System.out.println("hiii");
			}
		   
		   
		//H1 Tag count
		List<WebElement> findElements = driver.findElements(By.tagName("h1"));
		System.out.println("h1 count is:" +""+findElements.size());
	      Thread.sleep(2000);
	      String h1count = String.valueOf(findElements.size());
	      
         // System.out.println(h1count);
          if(h1count.equals("1")) {
        	  System.out.println("Pass");
        	  int parseInt = Integer.parseInt(INDEX);
  			Excel_Utils.writeinexcel9(h1count, parseInt);
          }else {
        	  System.out.println("Fail");
        	  int parseInt = Integer.parseInt(INDEX);
  			Excel_Utils.writeinexcel9(h1count, parseInt);
          }
          Thread.sleep(2000);

		// second parameter(Title)

		String Actualtitle = driver.getTitle().toLowerCase().trim();
		System.out.println(Actualtitle + "\t" + " --PAGE TITLE ");
		System.out.println(Title + "\t" + "--Excel Data");
		
		if (Actualtitle.equals(Title.trim())) {
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel2("PASS", parseInt);
			System.out.println("PASS");
		} else {
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel2("FAIL", parseInt);

			Excel_Utils.writeinexcel5(Actualtitle, parseInt);
			System.out.println("FAIL");
 
		}
		// 3 params(description)

		String pageDescription = lb.getPageDescription().toLowerCase().trim();

		System.out.println(pageDescription + "\t" + " --PAGE DESCRIPTION");
		System.out.println(Description + "\t" + "--Excel Data");

		if (pageDescription.equals(Description.trim())) {

			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel3("PASS", parseInt);
			System.out.println("PASS");

		} else {
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel3("FAIL", parseInt);
			Excel_Utils.writeinexcel6(pageDescription, parseInt);
			System.out.println("FAIL");
		}

		// 4 params (keywords)
		String pageKeywords = lb.getPageKeywords().toLowerCase().trim();
		System.out.println(pageKeywords + "\t" + " --PAGE KEYWORDS");
		System.out.println(keywords + "\t" + "--Excel Data");

		if (pageKeywords.equals(keywords.trim())) {
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel4("PASS", parseInt);

			System.out.println("PASS");
		} else {
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel4("FAIL", parseInt);
			Excel_Utils.writeinexcel7(pageKeywords, parseInt);
			System.out.println("FAIL");

		}
		try {
			SimpleDateFormat dateformet = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			Date date = new Date();
			String format = dateformet.format(date);
			int parseInt = Integer.parseInt(INDEX);
			Excel_Utils.writeinexcel13(format, parseInt);
			
			System.out.println(++count + "\t" + "is Row is completed." + "\t" + format);
		} catch (NumberFormatException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		

	}


	

	@AfterTest
	 public void driver_close() throws InterruptedException {
		 
		 Thread.sleep(2000);
			driver.quit();
	 }
	 
	
}
